<?php $__env->startComponent('mail::message'); ?>
# ¡Tu solicitud de reserva está en camino! 🏨

Hola **<?php echo e($data['user_info']['name']); ?>**, hemos recibido tu solicitud de reservación para pago directamente en recepción. Estamos procesando los detalles con el hotel.

<?php $__env->startComponent('mail::panel'); ?>
### 📋 Resumen de tu estancia
**Hotel:** <?php echo e($data['hotel_name'] ?? $data['hotel_code'] ?? 'Nuve Hotel'); ?>  
**Habitación:** <?php echo e($data['room_name']); ?>  
**Check-in:** <?php echo e(\Carbon\Carbon::parse($data['check_in'])->format('d/m/Y')); ?>  
**Check-out:** <?php echo e(\Carbon\Carbon::parse($data['check_out'])->format('d/m/Y')); ?>  

**Detalles adicionales:**
* **Adultos:** <?php echo e($data['adults']); ?>

* **Habitaciones:** <?php echo e($data['num_habs']); ?>

* **Plan:** Desayuno incluído por promoción
<?php echo $__env->renderComponent(); ?>

### 💳 Información Importante
Recuerda que esta modalidad es **Pago en Recepción**. Deberás liquidar el monto total al momento de tu llegada al hotel. 



**¿Qué sigue?** Te enviaremos un correo electrónico adicional en cuanto el hotel confirme la disponibilidad de tu habitación.

Si tienes alguna duda, responde a este correo o contáctanos al 870-148-3119.

Atentamente,  
El equipo de Nuve Hotel
<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\Users\lfrin\Documents\Github desktop\reservacion-nuve-hoteles\resources\views\emails\reservations\booking_in_reception_customer.blade.php ENDPATH**/ ?>