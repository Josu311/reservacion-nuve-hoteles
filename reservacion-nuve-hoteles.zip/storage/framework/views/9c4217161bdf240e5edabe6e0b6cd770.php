<?php $__env->startComponent('mail::message'); ?>
    # ¡Gracias por tu pago!

    Tu reservación quedó **confirmada**.

    <?php
        $roomTypes = [
            "S-" => "Sencilla",
            "D-" => "Doble"
        ];

        $hotelName = $reservation->hotel_code ?: 'Hotel no especificado';

        try {
            if ($reservation->hotel_code) {
                $hotelName = \App\Services\HotelConfig::name($reservation->hotel_code);
            }
        } catch (\Throwable $e) {
            // Conserva el código del hotel como fallback para no romper el correo.
        }

        $formatDate = static function ($value) {
            if (!$value) {
                return 'No disponible';
            }

            try {
                return \Carbon\Carbon::parse($value)->format('d/m/Y');
            } catch (\Throwable $e) {
                return 'No disponible';
            }
        };

        $attributes = $reservation->getAttributes();
        $checkinValue = $attributes['checkin'] ?? null;
        $checkoutValue = $attributes['checkout'] ?? null;
        $totalLabel = $totalMx ?? number_format(((int) ($reservation->amount_cents ?? 0)) / 100, 2);
        $currency = $reservation->currency ?: 'MXN';
    ?>

    **Folio:** <?php echo e($reservation->provider_folio ?: 'No disponible'); ?>

    **Hotel:** <?php echo e($hotelName); ?>


    **Habitación:** <?php echo e($roomTypes[$reservation->room_type_code] ?? ($reservation->room_type_code ?: 'No disponible')); ?>


    **Check-in:** <?php echo e($formatDate($checkinValue)); ?>

    **Check-out:** <?php echo e($formatDate($checkoutValue)); ?>

    **Noches:** <?php echo e($reservation->nights ?? 'No disponible'); ?>

    **Habitaciones:** <?php echo e($reservation->rooms ?? 'No disponible'); ?>

    **Adultos:** <?php echo e($reservation->adults ?? 'No disponible'); ?>


    **Total pagado:** $<?php echo e($totalLabel); ?> <?php echo e($currency); ?>


    <?php $__env->startComponent('mail::button', ['url' => url('/')]); ?>
        Visitar sitio
    <?php echo $__env->renderComponent(); ?>

    Si necesitas ayuda llámanos: 871-577-9488

    Gracias,<br>
    <?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\Users\lfrin\Documents\Github desktop\reservacion-nuve-hoteles\resources\views\emails\reservations\confirmed.blade.php ENDPATH**/ ?>