<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">

  <title><?php echo e($title); ?></title>
  <meta name="description" content="<?php echo e($description); ?>">

  <link rel="canonical" href="<?php echo e($canonical); ?>">

  <meta property="og:title" content="<?php echo e($title); ?>">
  <meta property="og:description" content="<?php echo e($description); ?>">
  <meta property="og:url" content="<?php echo e($url); ?>">
  <meta property="og:type" content="website">
  <meta property="og:site_name" content="Nuve Hotel">
  <meta property="og:image" content="<?php echo e($image); ?>">

  <meta name="twitter:card" content="summary_large_image">
  <meta name="twitter:title" content="<?php echo e($title); ?>">
  <meta name="twitter:description" content="<?php echo e($description); ?>">
  <meta name="twitter:image" content="<?php echo e($image); ?>">
</head>
<body>
  <noscript>
    <a href="<?php echo e($canonical); ?>">Abrir página</a>
  </noscript>
</body>
</html>
<?php /**PATH C:\Users\lfrin\Documents\Github desktop\reservacion-nuve-hoteles\resources\views\share.blade.php ENDPATH**/ ?>