<?php $__env->startComponent('mail::message'); ?>
# Nueva Reservación para Pago en Recepción

Se ha recibido una solicitud de reserva a través del sistema. Estos son los detalles para su registro:

<?php $__env->startComponent('mail::panel'); ?>
### Datos del Huésped
**Nombre:** <?php echo e($data['user_info']['name']); ?> <?php echo e($data['user_info']['lastname']); ?>

**Email:** <?php echo e($data['user_info']['email']); ?>

**Teléfono:** <?php echo e($data['user_info']['phone']); ?>

<?php echo $__env->renderComponent(); ?>

### Detalles de la Estancia
<?php $__env->startComponent('mail::table'); ?>
| Concepto | Información |
| :--- | :--- |
| **Hotel** | <?php echo e($data['hotel_name'] ?? $data['hotel_code'] ?? 'Nuve Hotel'); ?> |
| **Habitación** | <?php echo e($data['room_name']); ?> |
| **Plan** | Desayuno incluído por promoción |
| **Check-in** | <?php echo e(\Carbon\Carbon::parse($data['check_in'])->format('d/m/Y')); ?> |
| **Check-out** | <?php echo e(\Carbon\Carbon::parse($data['check_out'])->format('d/m/Y')); ?> |
| **Cantidad** | <?php echo e($data['num_habs']); ?> Hab. / <?php echo e($data['adults']); ?> Adultos |
<?php echo $__env->renderComponent(); ?>



*Nota: Esta reservación está pendiente de confirmación manual en recepción.*

Gracias,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\Users\lfrin\Documents\Github desktop\reservacion-nuve-hoteles\resources\views\emails\reservations\booking_in_reception_admin.blade.php ENDPATH**/ ?>